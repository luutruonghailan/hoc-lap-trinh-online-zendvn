import { Component } from '@angular/core';


@Component({
	moduleId: module.id,
	selector: 'my-app',
	templateUrl: './app.component.html'
})


export class AppComponent { 
	title: string = "Project 03 - Input Properties";
	
	description: string = "Project 03 - Input Properties - Description";

	answer($event) : void {
		console.log($event);
	}


	componentTitle: string = "AppComponent";
	// resetColor: string = "#000804";
	resetColor: string = "#000804";

	changeColor($event) {
		this.resetColor = $event;
	}

	// funcResetColor(){
	// 	this.resetColor ="#000804";
	// }
}
