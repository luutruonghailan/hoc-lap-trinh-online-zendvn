import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppComponent }   from './app.component';


// 01 Template reference variables
import { VariableComponent } from './template-variable/variable.component';

// 02 Input
import { InputComponent } from './input/input.component';

// 03 Output
import { OutputComponent } from './output/output.component';

// 04 Template Tag
import { TemplateComponent } from './template/template.component';

// Project Setting Color
import { ControlComponent } from './proj-setting-color/control.component';
import { PreviewerComponent } from './proj-setting-color/previewer.component';





@NgModule({
	imports:      [ BrowserModule ],
	declarations: [ 
		AppComponent,
		ControlComponent,
		PreviewerComponent
		// TemplateComponent,
		// OutputComponent,
		// InputComponent,
		// VariableComponent
	],
	bootstrap:    [ AppComponent ]
})

export class AppModule { }
