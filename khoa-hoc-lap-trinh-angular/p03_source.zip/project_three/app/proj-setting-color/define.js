"use strict";
exports.BLUE = "#2E86C1";
exports.RED = "#F20941";
exports.GREEN = "#229954";
exports.BLACK = "#000804";
//# sourceMappingURL=define.js.map