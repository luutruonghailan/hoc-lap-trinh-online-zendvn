<template>
    <footer>
        <h1>{{ textFooter }}</h1>
    </footer>
</template>

<script>
export default {
    name: 'comp-footer',
    data() {
        return {
            textFooter: 'Hello Footer'
        }
    }
}
</script>

<style>

</style>
