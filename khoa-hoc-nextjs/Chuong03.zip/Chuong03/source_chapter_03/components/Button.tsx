import { useEffect } from "react"

export default function Button() {

    // useEffect(() => {
    //     console.log("After Render Button")
    //     return () => {
    //         console.log("Component Button Will Unmount")
    //     }
    // })
    return (
        <h1>Button Component</h1>
    )
}