export default function Login() {
    return (
        <h1>Login Page</h1>
    )
}

// localhost:3000/admin/user