export default function AdminPage() {
    return (
        <h1>Admin Page</h1>
    )
}
