export default function AdminPosts() {
    return (
        <h1>Admin -&gt; Posts Page</h1>
    )
}

// localhost:3000/admin/user

/*
admin
    posts
    user
    index.tsx

*/