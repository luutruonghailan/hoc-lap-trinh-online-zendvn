import React from "react";

export default function User() {
    return (
        <h1>Hello User</h1>
    )
}