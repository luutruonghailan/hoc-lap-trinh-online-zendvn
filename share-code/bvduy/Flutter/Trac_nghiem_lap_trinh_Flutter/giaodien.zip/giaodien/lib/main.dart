import 'package:flutter/material.dart';
import 'package:quizgame/pages/my_app.dart';

void main(List<String> args) {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const MyApp());
}
