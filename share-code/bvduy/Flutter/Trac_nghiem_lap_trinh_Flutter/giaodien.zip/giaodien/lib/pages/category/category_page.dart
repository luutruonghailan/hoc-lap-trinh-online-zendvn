import 'package:flutter/material.dart';
import 'package:quizgame/apps/utils/const.dart';
import 'package:quizgame/widgets/background_custom.dart';

class CategoryPage extends StatelessWidget {
  const CategoryPage({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          const BackgroundCustom(),
          SafeArea(
            child: GridView.builder(
              padding: EdgeInsets.symmetric(horizontal: paddingCustom(context)),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                crossAxisSpacing: 10,
                mainAxisSpacing: 10,
                childAspectRatio: 2 / 1,
              ),
              itemCount: 10,
              itemBuilder: (BuildContext context, int index) {
                return Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10),
                    color: Colors.primaries[index],
                  ),
                  child: Align(
                    child: Text('Item + $index'),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
