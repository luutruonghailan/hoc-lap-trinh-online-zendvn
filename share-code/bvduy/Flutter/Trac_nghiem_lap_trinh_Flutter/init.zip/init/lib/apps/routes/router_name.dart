class RoutersPath {
  static const String homePath = '/';
  static const String categoryPath = 'categoty';
  static const String articlePath = 'article';
}

class RoutersName {
  static const String homeName = 'home';
  static const String categoryName = 'category';
  static const String articleName = 'article';
}
