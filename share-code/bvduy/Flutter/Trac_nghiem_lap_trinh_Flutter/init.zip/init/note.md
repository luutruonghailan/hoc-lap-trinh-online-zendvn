1. Open file init
2. Run : flutter create .

