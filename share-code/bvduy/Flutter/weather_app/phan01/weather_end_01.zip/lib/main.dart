import 'package:flutter/material.dart';
import 'package:weather/page/my_app.dart';

void main(List<String> args) {
  WidgetsFlutterBinding.ensureInitialized();

  runApp(const MyApp());
}
