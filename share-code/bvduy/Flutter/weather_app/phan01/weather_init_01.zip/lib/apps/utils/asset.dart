class AssetCustom {}
