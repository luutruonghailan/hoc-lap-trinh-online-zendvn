## Trang chủ 
1. Chia tách giao diện
    - Tách phần dùng chung vào folder html 
2. Chuẩn bị các libs
    - Github luutruonghailan 
    - Claim lib Session, Validate 
3. Sử dụng Fake Filler ext 
4. Chuẩn bị tài khoản google để gửi mail ra
5. Thực hiện chức năng 
    - Nhúng Google Map bằng iframe
    - Fill form và Validate 
    - Gửi mail dùng PHPMailer 
    - Nhúng Google Captcha v2 
    - Validate có Google Captcha 
    - Lưu dữ liệu vào json 
6. Optimize 
## Trang liên hệ 
1. Thực hiện chức năng
    - Đọc data từ json đổ ra table 
    - Viết Js tương tác cho button 
    - Giới thiệu PhpSpreadsheet, Mpdf 
    - Viết code xử lý xuất excel
    - Viết code xử lý xuất pdf
## Trang cấu hình 
1. Thực hiện chức năng 
    - Đọc thông tin email gửi từ json đổ ra form 
    - Lưu dữ liệu khi thay đổi 
    - 
